import "./Footer.css";

export default function Footer() {
  return (
    <div className="footer">
      <p> <a href = "">Privacy Policy</a>&nbsp;| © 2022 Highradius Corporation. All Rights Reserved.</p>
      
    </div>
  );
}
